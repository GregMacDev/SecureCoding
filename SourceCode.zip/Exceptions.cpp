// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>
#include <exception>

// Custom basic exception that is derived from exception
struct CustomException : public std::exception {
    const char* what() const throw() {
        return "Custom Exception Message";
    }
};

bool do_even_more_custom_application_logic()
{

    // Throws standard exception to be caught by the try/catch block wrapping the function call.
    throw std::exception("Exception Thrown\n");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    
    std::cout << "Running Custom Application Logic." << std::endl;

    // Try/catch block that catches the exception being thrown by the called function
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (std::exception& e) {
        std::cout << "Exception Occurred" << std::endl << e.what();
    }

    // Throws the custom exception I creatd that was derived from std::exception
    // Will be caught in main()
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // checks if the denominator is zero and throws a divide by zero exception appropriately
    if (den == 0) {
        throw std::runtime_error("Error. Cannot divide by Zero\n");
    }
    return (num / den);
}

void do_division() noexcept
{

    float numerator = 10.0f;
    float denominator = 0;

    // try/catch block that wraps the divide function call to catch the exception if the denomiator is zero.
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::runtime_error& e) {
        std::cout << "Exception Occurred" << std::endl << e.what();
    }
}

int main()
{
    // Try/catch block surrounding main() to catch any uncaught exceptions
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        do_division();

        // specific try/catch block that catches the custom created exception derived from std::exception
        try {
            do_custom_application_logic();
        }
        catch (CustomException& e) {
            std::cout << "Custom Exception Occurred" << std::endl << e.what();
        }
    }
    catch (...) {
        std::cout << "Caught Undetermined Exception" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu