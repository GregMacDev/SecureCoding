// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    // is the collection still empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, what must the size be?
    ASSERT_EQ(collection->size(), 1);
}

TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(5);

    // is the collection still empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, what must the size be?
    ASSERT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, MaxSizeIsGreaterOrEqual)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the max size must be greater or equal to zero
    EXPECT_GE(collection->max_size(), 0);

    add_entries(1);

    // if empty, the max size must be greater or equal to zero
    EXPECT_GE(collection->max_size(), 1);

    add_entries(5);

    // if empty, the max size must be greater or equal to zero
    EXPECT_GE(collection->max_size(), 5);

    add_entries(10);

    // if empty, the max size must be greater or equal to zero
    EXPECT_GE(collection->max_size(), 10);
}

TEST_F(CollectionTest, CapacityIsGreaterOrEqual)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the capacity must be greater or equal to zero
    EXPECT_GE(collection->capacity(), 0);

    add_entries(1);

    // if empty, the capacity must be greater or equal to 1
    EXPECT_GE(collection->capacity(), 1);

    add_entries(5);

    // if empty, the capacity must be greater or equal to 5
    EXPECT_GE(collection->capacity(), 5);

    add_entries(10);

    // if empty, the capacity must be greater or equal to 10
    EXPECT_GE(collection->capacity(), 10);
}

TEST_F(CollectionTest, ResizingIncrease)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the collection should be a size of 0
    EXPECT_EQ(collection->size(), 0);

    // resize collection to 5
    collection->resize(5);

    // the collection should have increased to a size of 5
    EXPECT_EQ(collection->size(), 5);

}

TEST_F(CollectionTest, ResizingDecrease)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the collection should be a size of 0
    EXPECT_EQ(collection->size(), 0);

    add_entries(5);

    // is the collection at a size 5 after adding 5 entries?
    EXPECT_EQ(collection->size(), 5);

    collection->resize(2);

    // is the collection at a size 2 after resizing it to 2?
    ASSERT_EQ(collection->size(), 2);
}

TEST_F(CollectionTest, ResizingDecreaseZero)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the collection should be a size of 0
    EXPECT_EQ(collection->size(), 0);

    add_entries(5);

    // is the collection at a size 5 after adding 5 entries?
    ASSERT_EQ(collection->size(), 5);

    collection->resize(0);

    // is the collection zero after resizing it to zero?
    ASSERT_TRUE(collection->empty());
}

TEST_F(CollectionTest, ClearErase)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the collection should be a size of 0
    EXPECT_EQ(collection->size(), 0);

    add_entries(5);

    // is the collection at a size 5 after adding 5 entries?
    EXPECT_EQ(collection->size(), 5);

    collection->clear();

    // is the collection empty after clearing the collection?
    ASSERT_TRUE(collection->empty());
}

TEST_F(CollectionTest, EraseCollection)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the collection should be a size of 0
    EXPECT_EQ(collection->size(), 0);

    add_entries(5);

    // is the collection at a size 5 after adding 5 entries?
    EXPECT_EQ(collection->size(), 5);

    collection->erase(collection->begin(),collection->end());

    // is the collection empty after erasing the collection from begin to end?
    ASSERT_TRUE(collection->empty());
}

TEST_F(CollectionTest, ReserveIncreaseOnlyCapacity)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the collection should be a size of 0
    EXPECT_EQ(collection->size(), 0);

    add_entries(5);

    // is the collection at a size 5 after adding 5 entries?
    EXPECT_EQ(collection->size(), 5);

    collection->reserve(20);

    // is the collection at capacity 20 after increasing the reserve to 20?
    ASSERT_EQ(collection->capacity(), 20);
    // is the size of the collection still at 5 after increasing the reserve capacity?
    ASSERT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, OutOfRangeException)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the collection should be a size of 0
    EXPECT_EQ(collection->size(), 0);

    add_entries(2);

    // is the collection at a size 2 after adding 2 entries?
    ASSERT_EQ(collection->size(), 2);

    // is an out_of_range exception thrown when attempting to access an element outside the range of the collection?
    ASSERT_THROW(collection->at(collection->size()), std::out_of_range);
}

TEST_F(CollectionTest, ShrinkToFit)
{
    // is the collection empty?
    EXPECT_EQ(collection->size(), 0);

    collection->reserve(10);

    // is the capacity increased to 10 by reserving 10?
    EXPECT_EQ(collection->capacity(), 10);

    // did the size remain the same, at zero, after the capacity increased?
    EXPECT_EQ(collection->size(), 0);

    collection->resize(5);

    // does the capacity remain at 10 after the resize?
    EXPECT_EQ(collection->capacity(), 10);
    // does the size increase to 5 after resizing the collection to 5?
    EXPECT_EQ(collection->size(), 5);

    collection->shrink_to_fit();

    // does the size of the collection remain the same after shrinking the capacity to fit the size?
    EXPECT_EQ(collection->size(), 5);
    // does the capacity shrink to equal the size after shrinking to fit?
    EXPECT_EQ(collection->capacity(), 5);
}

TEST_F(CollectionTest, ResizeNegativeTest)
{
    // does the collection throw and exception when attempting to resize the collection to a negative number?
    ASSERT_THROW(collection->resize(-1), std::exception);
}